import React, { Component } from 'react'

class NotFound extends Component {
  render () {
    return (
      /* Error Messaged displayed when a URL doesn't exist */
      <h1>Nothing is here, try somewhere else!</h1>
    )
  }
}

export default NotFound
